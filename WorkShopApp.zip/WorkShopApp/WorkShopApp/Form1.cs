﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mono.Security;
using Npgsql;

namespace WorkShopApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataShow dataShow = new DataShow();
            dataShow.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int counter = 0;
            foreach (RadioButton rb in groupBox1.Controls.OfType<RadioButton>())
            {
                if (rb.Checked)
                {
                    switch (counter)
                    {
                        case 2:
                            var insertCars = new InsertCars();
                            insertCars.Show();
                            break;
                        case 1:
                            var insertData = new InsertData();
                            insertData.Show();
                            break;
                        case 0:
                            var insertRepairs = new InsertRepairs();
                            insertRepairs.Show();
                            break;
                        default:
                            return;
                    }
                    return;
                }
                counter++;
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            int counter = 0;

            foreach (RadioButton rb in groupBox3.Controls.OfType<RadioButton>())
            {
                if (rb.Checked)
                {
                    switch (counter)
                    {
                        case 2:
                            var editCars = new EditCars();
                            editCars.Show();
                            break;
                        case 1:
                            var editWorkers = new EditWorkers();
                            editWorkers.Show();
                            break;
                        case 0:
                            var editRepairs = new EditRepairs();
                            editRepairs.Show();
                            break;
                        default:
                            return;
                    }
                    return;
                }
                counter++;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int counter = 0;
            foreach (RadioButton rb in groupBox2.Controls.OfType<RadioButton>())
            {
                if (rb.Checked)
                {
                    switch (counter)
                    {
                        case 2:
                            var deleteCars = new DeleteCars();
                            deleteCars.Show();
                            break;
                        case 1:
                            var deleteWorkers = new DeleteWorkers();
                            deleteWorkers.Show();
                            break;
                        case 0:
                            var deleteRepairs = new DeleteRepairs();
                            deleteRepairs.Show();
                            break;
                        default:
                            return;
                    }
                    return;
                }
                counter++;
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void обАвтореToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Author : Kyppygyrov Saryal Vasilievish\n" +
                "Email : jbwrestlingusa@gmail.com\n" +
                "Yakutsk, 2018" +
                "");
        }

        private void оДоходахToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Income inc = new Income();
            inc.Text = "Income";
            inc.Show();
        }

        private void оМашинахToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cars cars = new Cars();
            cars.Show();
        }
    }
}
