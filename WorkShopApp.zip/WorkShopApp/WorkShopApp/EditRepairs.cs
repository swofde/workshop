﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class EditRepairs : Form
    {
        List<String> workersIdList;
        List<String> carsIdList;
        String selectedWorkersIndexes;

        public EditRepairs()
        {
            InitializeComponent();
            workersIdList = new List<String>();
            carsIdList = new List<String>();
            textBox2.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
        }

        private void TextBoxes_KeyPress_ForCharactersOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !(e.KeyChar == ' '))
            {
                e.Handled = true;
            }
        }

        private void EditRepairs_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void getData()
        {
            checkedListBox1.Items.Clear();
            checkedListBox2.Items.Clear();
            checkedListBox3.Items.Clear();
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT NAME||' '||SURNAME || ' - '|| ROLE AS FULLNAME, ID FROM WORKER";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    foreach (DataRow r in dt.Rows)
                    {
                        checkedListBox1.Items.Add(r[0].ToString());
                        workersIdList.Add(r[1].ToString());
                    }

                    conn.Open();
                    cmd.CommandText = "SELECT ID FROM REPAIR";
                    dataReader = cmd.ExecuteReader();
                    DataTable dt1 = new DataTable();
                    dt1.Load(dataReader);
                    conn.Close();
                    foreach (DataRow r in dt1.Rows)
                    {
                        checkedListBox3.Items.Add(r[0].ToString());
                    }

                    conn.Open();
                    cmd.CommandText = "SELECT TYPE, ID FROM CAR";
                    dataReader = cmd.ExecuteReader();
                    dt1 = new DataTable();
                    dt1.Load(dataReader);
                    conn.Close();
                    foreach (DataRow r in dt1.Rows)
                    {
                        checkedListBox2.Items.Add(r[0].ToString());
                        carsIdList.Add(r[1].ToString());
                    }

                    conn.Open();
                    cmd.CommandText = "SELECT * FROM REPAIR";
                    dataReader = cmd.ExecuteReader();
                    dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void processAllWorkersIDs()
        {
            selectedWorkersIndexes = "{";
            foreach (int i in checkedListBox1.SelectedIndices)
            {
                //MessageBox.Show(i.ToString());
                selectedWorkersIndexes += workersIdList[i] + ',';
            }
            selectedWorkersIndexes = selectedWorkersIndexes.Remove(selectedWorkersIndexes.Length - 1, 1);
            selectedWorkersIndexes += '}';
            //MessageBox.Show(selectedWorkersIndexes);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox3.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please, select repair id.");
                return;
            }

            String connection =
              "Host=localhost;" +
              "Port=5432;" +
              "Database=workshop;" +
              "Username=postgres;" +
              "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    
                    cmd.Connection = conn;
                    if (checkedListBox1.SelectedIndices.Count > 0)
                    {
                        processAllWorkersIDs();
                        cmd.CommandText =
                            "UPDATE REPAIR " +
                            "SET WORKER_ID = '" + selectedWorkersIndexes + "' " +
                            "WHERE ID = " + checkedListBox3.SelectedItem.ToString();
                        execute(cmd);
                    }
                    conn.Close();

                    conn.Open();
                    if (checkedListBox2.SelectedItems.Count == 1)
                    {
                        cmd.CommandText =
                            "UPDATE REPAIR " +
                            "SET CAR_ID = " + carsIdList[checkedListBox2.SelectedIndex] + " " +
                            "WHERE ID = " + checkedListBox3.SelectedItem.ToString();
                        execute(cmd);
                        cmd.CommandText = 
                            "UPDATE CAR " +
                            "SET REP_ID = " + checkedListBox3.SelectedItem.ToString() + " " +
                            "WHERE ID = " + carsIdList[checkedListBox2.SelectedIndex];
                        execute(cmd);
                    }
                    conn.Close();


                    conn.Open();
                    if (textBox2.Text.Length > 0)
                    {
                        cmd.CommandText =
                            "UPDATE REPAIR " +
                            "SET DEFECT_TYPE = '" + textBox2.Text + "' " +
                            "WHERE ID = " + checkedListBox3.SelectedItem.ToString();
                        execute(cmd);
                    }
                    conn.Close();
                }
            }
            MessageBox.Show("Success");
        }

        private void execute(NpgsqlCommand cmd)
        {
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}
