﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class InsertData : Form
    {

        public InsertData()
        {
            InitializeComponent();
        }

        private void InsertData_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }

        private void getData()
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM WORKER";
                    cmd.Prepare();
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    dataGridView1.DataSource = dt;
                    conn.Close();
                }
            }
        }

        private void insertData()
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "INSERT INTO WORKER VALUES(@id, @name, @surname, @role, @empdate)";
                    cmd.Parameters.Add("id", textBox1.Text);
                    cmd.Parameters.Add("name", textBox2.Text);
                    cmd.Parameters.Add("surname", textBox3.Text);
                    cmd.Parameters.Add("role", textBox4.Text);
                    cmd.Parameters.Add("empdate", dateTimePicker1.Value.ToShortDateString().Replace('.', '-'));
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    conn.Close();
                }
            }
            MessageBox.Show("Success");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private int compare(TextBox a, TextBox b)
        {
            return String.Compare(a.Text, b.Text);
        }


    private void button1_Click(object sender, EventArgs e)
        {
            var container = splitContainer1.Panel1.Controls.OfType<TextBox>().ToArray();

            Array.Sort(container, compare);

            if (hasCharacters(container[0].Text) || container[0].Text.Length == 0)
            {
                MessageBox.Show("No characters in 'id' field. \n 'id' field cannot be empty!");
            }
            for (int i = 1; i < container.Length; i++)
            {
                MessageBox.Show(container[i].Text);
                if (hasDigit(container[i].Text) || container[i].Text.Length == 0)
                {
                    MessageBox.Show("No digits in fields 2-4 and no empty fields!");
                    return;
                }
            }
            insertData();
        }

        private bool hasDigit(String s)
        {
            foreach (char c in s.ToCharArray())
            {
                if (c >= '0' && c <='9') return true;
            }
            return false;
        }

        private bool hasCharacters(String s)
        {
            foreach (char c in s)
            {
                if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
                    return true;
            }
            return false;
        }
    }
}
