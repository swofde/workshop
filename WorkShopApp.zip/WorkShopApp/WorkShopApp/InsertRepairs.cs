﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class InsertRepairs : Form
    {

        List<String> workersIdList;
        List<String> carsIdList;
        String selectedWorkersIndexes;

        public InsertRepairs()
        {
            InitializeComponent();
            workersIdList = new List<String>();
            carsIdList = new List<String>();
            textBox1.KeyPress += TextBox_KeyPress;
            textBox2.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
        }

        private void InsertRepairs_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBoxes_KeyPress_ForCharactersOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !(e.KeyChar == ' '))
            {
                e.Handled = true;
            }
        }

        private void getWorkers()
        {
            String connection =
              "Host=localhost;" +
              "Port=5432;" +
              "Database=workshop;" +
              "Username=postgres;" +
              "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT NAME||' '||SURNAME AS FULLNAME FROM WORKER";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    dataGridView1.DataSource = dt;
                    conn.Close();
                }
            }
        }

        private void getData()
        {
            checkedListBox1.Items.Clear();
            checkedListBox2.Items.Clear();
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT NAME||' '||SURNAME || ' - '|| ROLE AS FULLNAME, ID FROM WORKER";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    foreach (DataRow r in dt.Rows)
                    {
                        checkedListBox1.Items.Add(r[0].ToString());
                        workersIdList.Add(r[1].ToString());
                    }

                    conn.Open();
                    cmd.CommandText = "SELECT TYPE, ID FROM CAR";
                    dataReader = cmd.ExecuteReader();
                    DataTable dt1 = new DataTable();
                    dt1.Load(dataReader);
                    conn.Close();
                    foreach (DataRow r in dt1.Rows)
                    {
                        checkedListBox2.Items.Add(r[0].ToString());
                        carsIdList.Add(r[1].ToString());
                    }

                    conn.Open();
                    cmd.CommandText = "SELECT * FROM REPAIR";
                    dataReader = cmd.ExecuteReader();
                    dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || checkedListBox1.SelectedItems.Count == 0 ||
               textBox2.Text.Length == 0 || checkedListBox2.SelectedItems.Count == 0)
            {
                MessageBox.Show("NO EMPTY FIELDS!");
                return;
            }
            if (checkedListBox2.SelectedItems.Count > 1)
            {
                MessageBox.Show("ONLY ONE CAR CAN BE SELECTED!");
                return;
            }

            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    processAllWorkersIDs();
                    cmd.Connection = conn;
                    cmd.CommandText = "INSERT INTO REPAIR" +
                        " VALUES(@id, '" + selectedWorkersIndexes + "', @car_id, @defect_type)";
                    cmd.Parameters.Add("id", textBox1.Text);
                    cmd.Parameters.Add("defect_type", textBox2.Text);
                    cmd.Parameters.Add("car_id", int.Parse(carsIdList[checkedListBox2.SelectedIndex]));
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                        return;
                    }
                    cmd.Parameters.Clear();
                    cmd.CommandText = "UPDATE CAR " +
                                      "SET rep_id = (SELECT id FROM REPAIR WHERE car_id = " + int.Parse(carsIdList[checkedListBox2.SelectedIndex]) + " ); ";
                                      
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                        return;
                    }
                    conn.Close();
                }
            }
            MessageBox.Show("Success");

        }

        private void processAllWorkersIDs()
        {
            selectedWorkersIndexes = "{";
            foreach (int i in checkedListBox1.SelectedIndices)
            {
                MessageBox.Show(i.ToString());
                selectedWorkersIndexes += workersIdList[i] + ',';
            }
            selectedWorkersIndexes = selectedWorkersIndexes.Remove(selectedWorkersIndexes.Length-1, 1);
            selectedWorkersIndexes += '}';
            MessageBox.Show(selectedWorkersIndexes);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }
    }
}
