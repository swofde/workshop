﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class Income : Form
    {

        Double[] months = new Double[12];
        String[] mNames =
        {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "Decemer"
        };
        String finalString = "";

        public Income()
        {
            InitializeComponent();
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0)
            {
                MessageBox.Show("Write a year");
                return;
            }
            processAllMonths(textBox1.Text);
            Double total = 0;
            for (int i = 0; i < 12; i++)
            {
                finalString += mNames[i] + " : " + months[i].ToString() + "$\n";
                total += months[i];
            }
            finalString += "\n\nTotal : " + total.ToString() + "$";
            Error er = new Error(finalString);
            er.Text = "Income summary of year - " + textBox1.Text;
            er.Show();
        }

        private void processAllMonths(string year)
        {
            finalString = "";
            String connection =
             "Host=localhost;" +
             "Port=5432;" +
             "Database=workshop;" +
             "Username=postgres;" +
             "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                using (var cmd = new NpgsqlCommand())
                {
                    object amount;
                    NpgsqlDataReader dataReader;
                    DataTable dt;
                    cmd.Connection = conn;
                    for (int i = 0; i < 11; i++)
                    {
                        cmd.CommandText = "SELECT SUM(PRICE) FROM CAR " +
                            "WHERE END_DATE >= '01-"+(i+1).ToString()+"-" +year+ "' " +
                            "AND END_DATE < '01-" + (i+2).ToString() + "-" + year + "'; ";
                        conn.Open();
                        dataReader = cmd.ExecuteReader();
                        dt = new DataTable();
                        dt.Load(dataReader);
                        conn.Close();
                        amount = dt.Rows[0]["sum"];
                        if (amount.Equals(DBNull.Value)) months[i] = 0;
                        else months[i] = ((IConvertible)amount).ToDouble(null);
                    }
                    cmd.CommandText = 
                        "SELECT SUM(PRICE) FROM CAR " +
                        "WHERE END_DATE >= '01-12-" + year + "' " +
                        "AND END_DATE < '31-12-" + year + "'; ";
                    conn.Open();
                    dataReader = cmd.ExecuteReader();
                    dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    amount = dt.Rows[0]["sum"];
                    if (amount.Equals(DBNull.Value)) months[11] = 0;
                    else months[11] = ((IConvertible)amount).ToDouble(null);                    
                }
            }

        }

        private void Income_Load(object sender, EventArgs e)
        {

        }
    }
}
