﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class DataShow : Form
    {

        enum Mode
        {
            Null,
            Worker,
            Car,
            Repair
        }

        Mode type;

        public DataShow()
        {
            InitializeComponent();
            type = Mode.Null;
            comboBox1.SelectedValueChanged += ComboBox1_SelectedValueChanged;
        }

        private void ComboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                switch (comboBox1.SelectedItem.ToString())
                {
                    case "Workers":
                        type = Mode.Worker;
                        break;
                    case "Repairs":
                        type = Mode.Repair;
                        break;
                    case "Cars":
                        type = Mode.Car;
                        break;         
                    default:
                        type = Mode.Null;
                        break;
                }
            }
            catch (Exception ex)
            {
                Error er = new Error(ex.ToString());
                er.Show();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    String tableName;
                    switch (type)
                    {
                        case Mode.Car:
                            tableName = "CAR";
                            break;
                        case Mode.Repair:
                            tableName = "REPAIR";
                            break;
                        case Mode.Worker:
                            tableName = "WORKER";
                            break;
                        case Mode.Null:
                            return;
                        default:  return;
                    }
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM " + tableName;
                    cmd.Prepare();

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    dataGridView1.DataSource = dt;

                    conn.Close();
                }
            }
            
        }

        private void DataShow_Load(object sender, EventArgs e)
        {
            
        }
    }
}
