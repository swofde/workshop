﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkShopApp
{
    public partial class Error : Form
    {
        public Error(String exception)
        {
            InitializeComponent();
            richTextBox1.Text = exception;
        }

        public Error()
        {
            InitializeComponent();
        }

        private void Error_Load(object sender, EventArgs e)
        {

        }
    }
}
