﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class EditCars : Form
    {
        DateTime currentDateBegin;
        DateTime currentDateEnd;

        public EditCars()
        {
            InitializeComponent();
            textBox1.KeyPress += RegId_KeyPress;
            textBox2.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
            textBox3.KeyPress += TextBox_KeyPress_For_Double;
            textBox4.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
        }

        private void EditCars_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBox_KeyPress_For_Double(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void RegId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBoxes_KeyPress_ForCharactersOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !(e.KeyChar == ' '))
            {
                e.Handled = true;
            }
        }

        private void getData()
        {
            checkedListBox1.Items.Clear();
            String connection =
                  "Host=localhost;" +
                  "Port=5432;" +
                  "Database=workshop;" +
                  "Username=postgres;" +
                  "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM CAR";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    dataGridView1.DataSource = dt;
                    foreach (DataRow dr in dt.Rows)
                    {
                        checkedListBox1.Items.Add(dr["id"]);
                    }
                    conn.Close();
                }
            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Value = (DateTime)dataGridView1.Rows[checkedListBox1.SelectedIndex].Cells["begin_date"].Value;
            currentDateBegin = dateTimePicker1.Value;
            currentDateEnd = currentDateBegin;
        }

        private void commitDateChange(NpgsqlCommand cmd, NpgsqlConnection conn, DateTime dt, DateTimePicker dtp, String field)
        {
            conn.Open();
            if (dtp.Value != dt)
            {
                dateChange(cmd, conn, dt, dtp, field);
            }
            conn.Close();
        }
        private void dateChange(NpgsqlCommand cmd, NpgsqlConnection conn, DateTime dt, DateTimePicker dtp, String field)
        {
            cmd.CommandText =
                     "UPDATE CAR " +
                     "SET  " + field + " = '" + dtp.Value.ToShortDateString().Replace('.', '-') + "' " +
                     "WHERE ID = " + checkedListBox1.SelectedItem.ToString();
            execute(cmd);
        }

        private void commitFieldChange(TextBox tb, NpgsqlCommand cmd, String field, NpgsqlConnection conn)
        {
            conn.Open();
            if (tb.Text.Length > 0)
            {
                cmd.CommandText =
                    "UPDATE CAR " +
                    "SET " + field + " = '" + tb.Text + "' " +
                    "WHERE ID = " + checkedListBox1.SelectedItem.ToString();
                execute(cmd);
            }
            conn.Close();
        }
        private void execute(NpgsqlCommand cmd)
        {
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please, select worker id.");
                return;
            }

            String connection =
              "Host=localhost;" +
              "Port=5432;" +
              "Database=workshop;" +
              "Username=postgres;" +
              "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    if (MessageBox.Show(
                        "Change the repair finish day?",
                        "Warning", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        if (dateTimePicker1.Value.CompareTo(dateTimePicker2.Value) > 0)
                        {
                            MessageBox.Show("Repair end date cannot be earlier than begin one!\n Aborting.");
                            return;
                        }
                        conn.Open();
                        commitDateChange(cmd, conn, currentDateBegin, dateTimePicker1, "BEGIN_DATE");
                        dateChange(cmd, conn, currentDateEnd, dateTimePicker2, "END_DATE");
                        commitFieldChange(textBox1, cmd, "REGID", conn);
                        commitFieldChange(textBox2, cmd, "TYPE", conn);
                        commitFieldChange(textBox3, cmd, "PRICE", conn);
                        commitFieldChange(textBox4, cmd, "DEFECT_TYPE", conn);
                        conn.Close();
                    }
                }
            }
            MessageBox.Show("Success");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }
    }
}
