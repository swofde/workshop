﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class DeleteWorkers : Form
    {
        public DeleteWorkers()
        {
            InitializeComponent();
        }

        private void DeleteWorkers_Load(object sender, EventArgs e)
        {
            getData();
        }

        private void getData()
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM WORKER";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void deleteWorker(int id)
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "DELETE FROM WORKER WHERE ID = " + id.ToString();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE REPAIR SET WORKER_ID = array_remove(WORKER_ID, " + id.ToString() + ")";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Choose row, please.");
                return;
            }

            if (MessageBox.Show("Selected rows are referenced in other" +
                " tables, deleting them will cause cascade deletion, you may lose a lot of useful data. \n Continue?", "Warning", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                return;

            foreach (DataGridViewRow dr in dataGridView1.SelectedRows)
            {
                deleteWorker((int)dr.Cells["id"].Value);
            }

            MessageBox.Show("Success");
        }
    }
}
