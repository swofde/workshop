﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class InsertCars : Form
    {
        public InsertCars()
        {
            InitializeComponent();
            textBox1.KeyPress += TextBox_KeyPress;
            textBox4.KeyPress += TextBox_KeyPress_For_Double;
            textBox3.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
            textBox5.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
            textBox2.KeyPress += RegId_KeyPress;
        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBox_KeyPress_For_Double(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void RegId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void TextBoxes_KeyPress_ForCharactersOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !(e.KeyChar == ' '))
            {
                e.Handled = true;
            }
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void getData()
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM CAR";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    dataGridView1.DataSource = dt;
                    conn.Close();
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            getData();   
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkForEmpty())
            {
                MessageBox.Show("No empty fields");
                return;
            }
            insertData();
        }

        private bool checkForEmpty()
        {
            foreach(TextBox t in splitContainer1.Panel1.Controls.OfType<TextBox>().ToArray())
            {
                if (t.Text.Length == 0) return true;
            }
            return false;
        }

        private void insertData()
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "INSERT INTO CAR(id, regid, type, defect_type, price, begin_date)" +
                        " VALUES(@id, @regid,@type, @deftype, @price, @begdate)";
                    cmd.Parameters.Add("id", textBox1.Text);
                    cmd.Parameters.Add("regid", textBox2.Text);
                    cmd.Parameters.Add("type", textBox3.Text);
                    cmd.Parameters.Add("price", textBox4.Text);
                    cmd.Parameters.Add("deftype", textBox5.Text);
                    cmd.Parameters.Add("begdate", dateTimePicker1.Value.ToShortDateString().Replace('.', '-'));
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                        return;
                    }
                    conn.Close();
                }
            }
            MessageBox.Show("Success");
        }

        private void InsertCars_Load(object sender, EventArgs e)
        {
            getData();
        }
    }
}
