﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class DeleteRepairs : Form
    {
        public DeleteRepairs()
        {
            InitializeComponent();
        }

        private void DeleteRepairs_Load(object sender, EventArgs e)
        {
            getData();
        }
        private void getData()
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM REPAIR";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    conn.Close();
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void deleteRow(int id)
        {
            String connection =
               "Host=localhost;" +
               "Port=5432;" +
               "Database=workshop;" +
               "Username=postgres;" +
               "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "DELETE FROM REPAIR WHERE ID = " + id.ToString();
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE CAR SET REP_ID = NULL WHERE REP_ID = " + id.ToString();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Choose row, please.");
                return;
            }

            if (MessageBox.Show("Selected rows are referenced in other" +
                " tables, deleting them will cause cascade deletion," +
                " you may lose a lot of useful data. \n Continue?", 
                "Warning", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                return;

            foreach (DataGridViewRow dr in dataGridView1.SelectedRows)
            {
                deleteRow((int)dr.Cells["id"].Value);
            }

            MessageBox.Show("Success");
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
