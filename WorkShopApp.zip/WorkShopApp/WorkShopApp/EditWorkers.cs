﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using Mono.Security;

namespace WorkShopApp
{
    public partial class EditWorkers : Form
    {

        DateTime currentDate;

        public EditWorkers()
        {
            InitializeComponent();
            textBox1.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
            textBox2.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
            textBox3.KeyPress += TextBoxes_KeyPress_ForCharactersOnly;
        }

        private void EditWorkers_Load(object sender, EventArgs e)
        {
            getData();
        }
        private void getData()
        {
            checkedListBox1.Items.Clear();
            String connection =
                  "Host=localhost;" +
                  "Port=5432;" +
                  "Database=workshop;" +
                  "Username=postgres;" +
                  "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                conn.Open();

                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "SELECT * FROM WORKER";
                    NpgsqlDataReader dataReader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(dataReader);
                    dataGridView1.DataSource = dt;
                    foreach (DataRow dr in dt.Rows)
                    {
                        checkedListBox1.Items.Add(dr["id"]);
                    }                 
                    conn.Close();
                }
            }
        }

        private void TextBoxes_KeyPress_ForCharactersOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !(e.KeyChar == ' '))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Please, select worker id.");
                return;
            }

            String connection =
              "Host=localhost;" +
              "Port=5432;" +
              "Database=workshop;" +
              "Username=postgres;" +
              "Password=sandaara;";
            using (var conn = new NpgsqlConnection(connection))
            {
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;
                    commitFieldChange(textBox1, cmd, "NAME", conn);
                    commitFieldChange(textBox2, cmd, "SURNAME", conn);
                    commitFieldChange(textBox3, cmd, "ROLE", conn);
                    commitDateChange(cmd, conn);
                }
            }
            MessageBox.Show("Success");
        }

        private void commitDateChange( NpgsqlCommand cmd, NpgsqlConnection conn)
        {
            conn.Open();
            if (dateTimePicker1.Value != currentDate)
            {
                cmd.CommandText =
                    "UPDATE WORKER " +
                    "SET  EMPLOYMENT_DATE = '" + dateTimePicker1.Value.ToShortDateString().Replace('.', '-') + "' " +
                    "WHERE ID = " + checkedListBox1.SelectedItem.ToString();
                execute(cmd);
            }
            conn.Close();
        }

        private void commitFieldChange(TextBox tb, NpgsqlCommand cmd, String field, NpgsqlConnection conn)
        {
            conn.Open();
            if (tb.Text.Length > 0)
            {
                cmd.CommandText =
                    "UPDATE WORKER " +
                    "SET " + field + " = '" + tb.Text + "' " +
                    "WHERE ID = " + checkedListBox1.SelectedItem.ToString();
                execute(cmd);
            }
            conn.Close();
        }
        private void execute(NpgsqlCommand cmd)
        {
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            getData();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Value = (DateTime)dataGridView1.Rows[checkedListBox1.SelectedIndex].Cells["employment_date"].Value;
            currentDate = dateTimePicker1.Value;
        }
    }
}
